import 'dart:html';

import 'package:flutter/material.dart';
import 'package:varshini/home_page.dart';

import 'package:varshini/challenges_page.dart';
import 'package:varshini/community_page.dart';
import 'package:varshini/leaderboard_page.dart';
import 'package:varshini/tools_page.dart';
import 'package:varshini/profile_page.dart';

void main() {
  runApp(Myapp());
}

class Myapp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: ' FARMING',
      debugShowCheckedModeBanner: false,
      home: const MainPage(),
    );
  }
}

class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int _selectedindex = 0;

  final List<Widget> _pages = [
    homepage(),
    challenges(),
    community(),
    leaderboard_page(),
    toolsPage(),
    profile_page(),
  ];
  void _onItemTapped(int index) {
    setState(() {
      _selectedindex = index;
    });
  }

  void _navigateTo(int index) {
    Navigator.pop(context);
    setState(() {
      _selectedindex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.green[100],
        elevation: 0,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "FARMING",
              style:
                  TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
            ),
            Text(
              "Empowering Youth In Agriculture",
              style: TextStyle(color: Colors.black, fontSize: 20),
            ),
          ],
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.green),
              child: Text(" DASHBOARD",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 20,
                  )),
            ),
            ListTile(
              leading: const Icon(Icons.group),
              title: const Text('New group'),
            ),
            ListTile(
              leading: const Icon(Icons.star_rate),
              title: const Text('Stared'),
            ),
            ListTile(
              leading: const Icon(Icons.broadcast_on_home),
              title: const Text('New broadcast'),
            ),
            ListTile(
              leading: const Icon(Icons.payment),
              title: const Text('payment details'),
            ),
            ListTile(
              leading: const Icon(Icons.settings),
              title: const Text('Settings'),
            ),
            ListTile(
                leading: const Icon(Icons.person),
                title: const Text('Profile'),
                onTap: () => _navigateTo(5)),
          ],
        ),
      ),
      body: _pages[_selectedindex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedindex,
        selectedItemColor: Colors.green,
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Homepage',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.local_florist),
            label: 'Challenges',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.group),
            label: 'Community',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.leaderboard),
            label: 'Leaderboard',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.build),
            label: 'Tools',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
