import 'package:flutter/material.dart';

class challenges extends StatelessWidget {
  const challenges({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> challenges = [
      {
        'title': 'Water Scarcity',
        'description':
            'Limited water resources affect crop yield and sustainability.',
        'solution': 'Use drip irrigation and rainwater harvesting techniques.',
        'image':
            'https://th.bing.com/th/id/R.566858278789c788cc878ba997a9413a?rik=Jt60SFCwpnqVLQ&riu=http%3a%2f%2fd3i3l3kraiqpym.cloudfront.net%2fwp-content%2fuploads%2f2016%2f02%2f13105152%2fwater-scarcity.jpg&ehk=RFp94Z66iSVW99buYr2aj%2fkGFrkXTqrX%2bdWPp3DFs0U%3d&risl=&pid=ImgRaw&r=0',
      },
      {
        'title': 'Soil Degradation',
        'description':
            'Overuse of chemicals and poor farming practices reduce soil fertility.',
        'solution':
            'Adopt organic farming and use natural fertilizers like compost.',
        'image':
            'https://eco-nnect.com/wp-content/uploads/2022/01/img_61ea70dcdbb31.jpg',
      },
      {
        'title': 'Pest & Disease Control',
        'description':
            'Crops often suffer from pest infestations and diseases.',
        'solution': 'Implement crop rotation and biological pest control.',
        'image':
            'https://th.bing.com/th/id/R.e8f46dd322b9247d9254b6e2b54631e9?rik=VU%2bHJDx0JeTtIA&riu=http%3a%2f%2fwww.gardencentermag.com%2ffileuploads%2fpublications%2f13%2fissues%2f103138%2farticles%2fimages%2finsecticides-spay_fmt.png&ehk=uMuUP7hU6mdFmGdB869qyrRO%2fdwNlSV%2frbKKCFK5KHI%3d&risl=&pid=ImgRaw&r=0',
      },
      {
        'title': 'Climate Change',
        'description':
            'Unpredictable weather patterns harm agricultural productivity.',
        'solution': 'Grow climate-resilient crops and use smart farming tech.',
        'image':
            'https://as1.ftcdn.net/v2/jpg/05/64/59/70/1000_F_564597028_oqSoUMdViZgXacTsdxOV6k86tiHiZgFW.jpg',
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Farming Challenges',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.green.shade700,
        centerTitle: true,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: challenges.length,
        itemBuilder: (context, index) {
          final challenge = challenges[index];
          return Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            elevation: 4,
            margin: const EdgeInsets.symmetric(vertical: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Image Section
                ClipRRect(
                  borderRadius:
                      const BorderRadius.vertical(top: Radius.circular(16)),
                  child: Image.network(
                    challenge['image']!,
                    height: 180,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) => Container(
                      height: 180,
                      color: Colors.grey.shade200,
                      alignment: Alignment.center,
                      child: const Icon(Icons.broken_image,
                          size: 60, color: Colors.grey),
                    ),
                  ),
                ),
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        challenge['title']!,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.green,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        challenge['description']!,
                        style: const TextStyle(
                            fontSize: 15, color: Colors.black87),
                      ),
                      const SizedBox(height: 10),
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.green.shade50,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.lightbulb_outline,
                                color: Colors.orange),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                challenge['solution']!,
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontStyle: FontStyle.italic,
                                  color: Colors.black87,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
