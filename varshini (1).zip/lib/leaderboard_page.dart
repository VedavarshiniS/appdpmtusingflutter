import 'package:flutter/material.dart';

class leaderboard_page extends StatelessWidget {
  final List<Map<String, dynamic>> leaderboard = [
    {
      'name': 'Ravi Kumar',
      'score': 980,
      'image': 'https://cdn-icons-png.flaticon.com/512/616/616408.png'
    },
    {
      'name': 'Asha Devi',
      'score': 920,
      'image': 'https://cdn-icons-png.flaticon.com/512/6997/6997662.png'
    },
    {
      'name': 'Manoj Singh',
      'score': 870,
      'image': 'https://cdn-icons-png.flaticon.com/512/921/921071.png'
    },
    {
      'name': 'Kavitha',
      'score': 850,
      'image': 'https://cdn-icons-png.flaticon.com/512/2922/2922506.png'
    },
    {
      'name': 'Vijay Patel',
      'score': 830,
      'image': 'https://cdn-icons-png.flaticon.com/512/4140/4140048.png'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("🌾 Farming Leaderboard"),
        centerTitle: true,
        backgroundColor: Colors.green.shade700,
      ),
      body: Container(
        color: Colors.green.shade50,
        child: ListView.builder(
          itemCount: leaderboard.length,
          itemBuilder: (context, index) {
            final farmer = leaderboard[index];
            return Card(
              margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
              elevation: 3,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundImage: NetworkImage(farmer['image']),
                  radius: 30,
                ),
                title: Text(
                  farmer['name'],
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
                subtitle: Text(
                  "Score: ${farmer['score']}",
                  style: TextStyle(color: Colors.grey[700]),
                ),
                trailing: CircleAvatar(
                  backgroundColor: Colors.green.shade200,
                  child: Text(
                    "#${index + 1}",
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
