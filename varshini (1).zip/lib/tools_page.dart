import 'package:flutter/material.dart';

class toolsPage extends StatelessWidget {
  const toolsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> tools = [
      {
        'name': 'Tractor',
        'description':
            'Used for plowing, planting, and transporting heavy loads in the field.',
        'image':
            'https://www.deere.co.in/assets/images/region-1/products/tractors/john-deere-e-series-cab.jpg',
      },
      {
        'name': 'Plough',
        'description':
            'A basic tool used to prepare the soil for sowing seeds by turning it over.',
        'image':
            'https://www.tuckwells.com/wp-content/uploads/2020/05/ReversibleSlattedPlough2.jpg',
      },
      {
        'name': 'Seed Drill',
        'description':
            'Helps sow seeds evenly in the soil at proper depth and spacing.',
        'image':
            'https://5.imimg.com/data5/HG/JX/LB/SELLER-2497808/seed-drills-9-tyne-500x500.jpg',
      },
      {
        'name': 'Harvester',
        'description':
            'Used for harvesting crops efficiently, saving time and labor.',
        'image':
            'https://www.deere.ca/assets/images/region-4/products/harvesting/tseries-combine-r2C001197-1920x1080.jpg',
      },
      {
        'name': 'Irrigation Pump',
        'description':
            'Supplies water from wells or rivers to fields for irrigation.',
        'image':
            'https://tse4.mm.bing.net/th/id/OIP.7EUfuhpABgKBIvAInQ2R7QAAAA?rs=1&pid=ImgDetMain&o=7&rm=3',
      },
      {
        'name': 'Sprayer',
        'description':
            'Used to apply pesticides, herbicides, or fertilizers evenly on crops.',
        'image':
            'https://static1.backyardbossimages.com/wordpress/wp-content/uploads/2022/03/VIVOSUN-2-Gallon-Pump-Pressure-Sprayer.jpg',
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Farming Tools',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.green.shade700,
        centerTitle: true,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: tools.length,
        itemBuilder: (context, index) {
          final tool = tools[index];
          return Card(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            elevation: 4,
            margin: const EdgeInsets.symmetric(vertical: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Image Section
                ClipRRect(
                  borderRadius:
                      const BorderRadius.vertical(top: Radius.circular(16)),
                  child: Image.network(
                    tool['image']!,
                    height: 180,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) => Container(
                      height: 180,
                      color: Colors.grey.shade200,
                      alignment: Alignment.center,
                      child: const Icon(Icons.broken_image,
                          size: 60, color: Colors.grey),
                    ),
                  ),
                ),
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        tool['name']!,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.green,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        tool['description']!,
                        style: const TextStyle(
                            fontSize: 15, color: Colors.black87),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
