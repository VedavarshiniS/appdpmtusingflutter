import 'package:flutter/material.dart';

void main() {
  runApp(const NipixTechnology());
}

class NipixTechnology extends StatelessWidget {
  const NipixTechnology({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login Page',
      debugShowCheckedModeBanner: false,
      home: const homepage(),
    );
  }
}

class homepage extends StatefulWidget {
  const homepage({Key? key}) : super(key: key);
  @override
  State<homepage> createState() => __homepage();
}

class __homepage extends State<homepage> {
  final _formkey = GlobalKey<FormState>();
  String email = '';
  String password = '';
  bool showpass = true;
  void _submit() {
    if (_formkey.currentState!.validate()) {
      _formkey.currentState!.save();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('successfully log in as:$email'),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Welcome To Our Page"),
        backgroundColor: Colors.teal,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(30),
        child: Form(
          key: _formkey,
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            SizedBox(
              height: 20,
            ),
            TextFormField(
              decoration: InputDecoration(
                  labelText: "Email Id",
                  prefixIcon: Icon(Icons.email),
                  border: OutlineInputBorder()),
              keyboardType: TextInputType.emailAddress,
              validator: (value) {
                if (value == null || !value.contains('@gmail.com')) {
                  return ' enter the emailid';
                }
                return null;
              },
              onSaved: (value) => email = value!,
            ),
            SizedBox(
              height: 20,
            ),
            TextFormField(
              decoration: InputDecoration(
                  labelText: "Password",
                  prefixIcon: Icon(Icons.password),
                  border: OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(
                        showpass ? Icons.visibility : Icons.visibility_off),
                    onPressed: () => setState(() {
                      showpass = !showpass;
                    }),
                  )),
              obscureText: showpass,
              validator: (value) {
                if (value == null || value.length < 7) {
                  return 'password not contain 8 characters';
                }
                return null;
              },
              onSaved: (value) => password = value!,
            ),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: _submit,
              child: Text("Submit"),
            ),
          ]),
        ),
      ),
    );
  }
}
