import 'dart:html';

import 'package:flutter/material.dart';

void main() {
  runApp(Myapp());
}

class Myapp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: profile_page(),
    );
  }
}

class profile_page extends StatelessWidget {
  const profile_page({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(
          child: Text(
            "farmer profile",
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Colors.white,
              letterSpacing: 1.5,
            ),
          ),
        ),
        backgroundColor: Color(0xff7cbc7e),
        elevation: 4,
      ),
      backgroundColor: Color(0xffe8f5e9),
      body: Column(
        children: [
          const SizedBox(height: 30),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                infoBox(Icons.person, "name:varshini", context),
                infoBox(Icons.agriculture, "role:organic farming", context),
                infoBox(Icons.nature_people_sharp,
                    "interest:sustainable farming\n& animal care", context),
                infoBox(
                    Icons.school,
                    "education:diploma in agricultural practices\ngreen field institute",
                    context),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget infoBox(IconData icon, String text, BuildContext context) {
    return Container(
      width: 300,
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.green.shade100,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.green.shade700),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: Colors.green[900]),
          const SizedBox(width: 8),
          Expanded(
              child: Text(text,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 15)))
        ],
      ),
    );
  }
}
