import 'package:flutter/material.dart';

class community extends StatelessWidget {
  final List<Map<String, dynamic>> posts = [
    {
      'name': 'Ravi Kumar',
      'image': 'https://cdn-icons-png.flaticon.com/512/616/616408.png',
      'time': '2 hrs ago',
      'content':
          'Just harvested organic tomatoes today! 🍅 Yield was much better this season.',
      'postImage':
          'https://cdn.pixabay.com/photo/2017/03/16/10/56/tomatoes-2140677_1280.jpg',
    },
    {
      'name': 'Asha Devi',
      'image': 'https://cdn-icons-png.flaticon.com/512/6997/6997662.png',
      'time': '4 hrs ago',
      'content':
          'Does anyone have tips for preventing leaf spot disease in rice fields?',
      'postImage':
          'https://cdn.pixabay.com/photo/2016/11/29/09/32/rice-1869427_1280.jpg',
    },
    {
      'name': 'Manoj Singh',
      'image': 'https://cdn-icons-png.flaticon.com/512/921/921071.png',
      'time': '1 day ago',
      'content':
          'Tried a new organic fertilizer this week. 🌱 Plants are looking healthier already!',
      'postImage':
          'https://cdn.pixabay.com/photo/2017/06/06/13/19/soil-2372130_1280.jpg',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("👩‍🌾 Farming Community"),
        centerTitle: true,
        backgroundColor: Colors.green.shade700,
      ),
      body: ListView.builder(
        itemCount: posts.length,
        itemBuilder: (context, index) {
          final post = posts[index];
          return Card(
            margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
            elevation: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ListTile(
                  leading: CircleAvatar(
                    backgroundImage: NetworkImage(post['image']),
                    radius: 25,
                  ),
                  title: Text(
                    post['name'],
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(post['time']),
                ),
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Text(
                    post['content'],
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
                if (post['postImage'] != null)
                  ClipRRect(
                    borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(15),
                      bottomRight: Radius.circular(15),
                    ),
                    child: Image.network(post['postImage']),
                  ),
                const SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.thumb_up_alt_outlined),
                        onPressed: () {},
                      ),
                      const Text("Like"),
                      const SizedBox(width: 20),
                      IconButton(
                        icon: const Icon(Icons.comment_outlined),
                        onPressed: () {},
                      ),
                      const Text("Comment"),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.green.shade700,
        child: const Icon(Icons.add),
        onPressed: () {
          // Add new post action
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("New post feature coming soon!")),
          );
        },
      ),
    );
  }
}
